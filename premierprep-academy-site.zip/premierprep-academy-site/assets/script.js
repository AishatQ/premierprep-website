// PremierPrep Academy — shared behaviour

// Mainstack checkout links per program.
const PAYMENT_LINKS = {
  'digital-marketing': 'https://mainstack.com/p/premierprep-digital-marketing-program',
  'brand-design': 'https://mainstack.com/p/premierprep-brand-design-program',
  'virtual-assistant': 'https://mainstack.com/p/premierprep-virtual-assistance-program'
};

// Google Apps Script web app URL that writes enrollment form submissions into Google Sheets.
const SHEETS_ENDPOINT = 'https://script.google.com/macros/s/AKfycby3SLqpcu06vO8-YNJRBAdgSHEag0YAiYf9yVPoVPu5zXqpEP4gMgutQhtuXuXCDj7iiw/exec';

document.addEventListener('DOMContentLoaded', () => {
  // Mobile nav toggle
  const toggle = document.querySelector('.nav-toggle');
  const links = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', () => {
      links.classList.toggle('open');
    });
    links.querySelectorAll('a').forEach(a => a.addEventListener('click', () => links.classList.remove('open')));
  }

  // Scroll reveal
  const revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window && revealEls.length) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealEls.forEach(el => io.observe(el));
  } else {
    revealEls.forEach(el => el.classList.add('in'));
  }

  // Enrollment form -> program pre-select via query string (?program=digital-marketing)
  const params = new URLSearchParams(window.location.search);
  const programParam = params.get('program');
  if (programParam) {
    const radio = document.querySelector(`input[name="program"][value="${programParam}"]`);
    if (radio) radio.checked = true;
  }

  // Enrollment form submit -> writes to Google Sheets, then reveals payment step
  const form = document.getElementById('enrollment-form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();

      const submitBtn = form.querySelector('button[type="submit"]');
      const originalLabel = submitBtn ? submitBtn.textContent : '';
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = 'Submitting...';
      }

      const formData = new FormData(form);

      fetch(SHEETS_ENDPOINT, {
        method: 'POST',
        mode: 'no-cors',
        body: formData
      })
        .then(() => {
          const selected = form.querySelector('input[name="program"]:checked');
          const payBtn = document.getElementById('pay-now-btn');
          if (selected && payBtn && PAYMENT_LINKS[selected.value]) {
            payBtn.href = PAYMENT_LINKS[selected.value];
          }
          const confirmBox = document.getElementById('form-success');
          form.style.display = 'none';
          if (confirmBox) confirmBox.style.display = 'block';
          window.scrollTo({ top: form.offsetTop - 120, behavior: 'smooth' });
        })
        .catch(() => {
          if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = originalLabel;
          }
          alert("Something went wrong submitting your enrollment. Please try again, or reach out to us directly if it keeps happening.");
        });
    });
  }
});
